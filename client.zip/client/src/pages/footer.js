import React from "react";

function Footer() {
return(
<footer>
    <div class="footer-copyright text-center py-3">© 2020 Copyright:
        <a href="https://nowmozilla.club/">nowmozilla.club</a>
    </div>
	
</footer>

);
};

export default Footer;