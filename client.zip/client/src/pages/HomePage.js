import React, { useEffect, useState } from 'react';
import Footer from "./footer";
import './styles.css';
const HomePage = () => {
return(

<body>
<div class="mask rgba-gradient align-items-center">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <div class="wrapper">
        <nav class="navbar navbar-expand-lg navbar transparent navbar-inverse navbar-fixed-top">
            <a class="navbar-brand " href="#">CoursePlace</a>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link">SIGN UP</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link">LOGIN</a>
                </li>
            </ul>
        </nav>
    </div>
        <div class="row">
            <div class="col-md-6 text-center">
				<div class="text-center">
                <h1 class="subheading mb-xl-4 pb-xl-0 mb-md-3 pb-md-3 mb-4 text-white"><strong>Course Place </strong></h1>
                <h6 class="mb-4 text-white ">This site helps you by finding the best course suited for you so you can do more of the learning and spend less time searching for the course!</h6>
				</div>
            </div>
            <div class="col-md-6 col-xl-5 mt-xl-5 text-white wow fadeInRight">
                <img src="https://mdbootstrap.com/img/illustrations/graphics(3).png" class="img-fluid" alt="Responsive image" />
            </div>
        </div>
    <Footer />
</div>
</body>

);
};

export default HomePage;